import json
import boto3
import os
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
 
# Config
REGION = 'us-east-1'
OPENSEARCH_ENDPOINT = os.environ['OPENSEARCH_ENDPOINT']
INDEX_NAME = 'umd-knowledge'
TOP_K = 3  # How many chunks to retrieve
 
# AWS clients
bedrock = boto3.client('bedrock-runtime', region_name=REGION)
 
# OpenSearch auth using Lambda's role
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(
    credentials.access_key,
    credentials.secret_key,
    REGION,
    'aoss',
    session_token=credentials.token
)
 
opensearch = OpenSearch(
    hosts=[{'host': OPENSEARCH_ENDPOINT.replace('https://', ''), 'port': 443}],
    http_auth=awsauth,
    use_ssl=True,
    verify_certs=True,
    connection_class=RequestsHttpConnection
)
 
 
def get_embedding(text):
    """Generate embedding for the user's question."""
    response = bedrock.invoke_model(
        modelId='amazon.titan-embed-text-v1',
        body=json.dumps({'inputText': text})
    )
    return json.loads(response['body'].read())['embedding']
 
 
def search_knowledge_base(question_embedding, k=TOP_K):
    """Find the k most relevant chunks for the user's question."""
    query = {
        'size': k,
        'query': {
            'knn': {
                'embedding': {
                    'vector': question_embedding,
                    'k': k
                }
            }
        },
        '_source': ['text', 'source']
    }
    response = opensearch.search(index=INDEX_NAME, body=query)
    return [hit['_source'] for hit in response['hits']['hits']]
 
 
def handler(event, context):
    body = json.loads(event.get('body', '{}'))
    user_message = body.get('message', '')
 
    max_length = 100
    if len(user_message) > max_length:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': f'Message exceeds maximum length of {max_length} characters'})
        }
 
    if not user_message:
        return {'statusCode': 400, 'body': json.dumps({'error': 'No message provided'})}
 
    # Step 1: Embed the question
    question_embedding = get_embedding(user_message)
 
    # Step 2: Retrieve relevant chunks from OpenSearch
    relevant_chunks = search_knowledge_base(question_embedding)
 
    # Step 3: Build context string for Claude
    context_text = "\n\n".join([
        f"[Source: {chunk['source']}]\n{chunk['text']}"
        for chunk in relevant_chunks
    ])
 
    # Step 4: Call Claude with retrieved context
    system_prompt = (
        "You are a helpful UMD (University of Maryland) assistant. "
        "Answer the user's question using the context below. "
        "If the context doesn't contain the answer, say so honestly rather than guessing.\n\n"
        f"Context:\n{context_text}"
    )
 
    response = bedrock.invoke_model(
        modelId='us.anthropic.claude-sonnet-4-6',
        body=json.dumps({
            'anthropic_version': 'bedrock-2023-05-31',
            'max_tokens': 1024,
            'temperature': 0.7,
            'system': system_prompt,
            'messages': [{'role': 'user', 'content': user_message}]
        })
    )
 
    result = json.loads(response['body'].read())
    reply = result['content'][0]['text']
 
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
        'body': json.dumps({'reply': reply})
    }